package com.koncert.ris;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KoncertApplication {

	public static void main(String[] args) {
		SpringApplication.run(KoncertApplication.class, args);
	}

}
