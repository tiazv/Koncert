package com.koncert.ris.models;

public enum Zvrst {
    POP,
    ROCK,
    HIPHOP,
    JAZZ,
    CLASSICAL,
    INDIE,
    HOUSE,
    METAL
}
